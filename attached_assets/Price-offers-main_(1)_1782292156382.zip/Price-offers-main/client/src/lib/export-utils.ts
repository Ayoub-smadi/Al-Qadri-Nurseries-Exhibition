import html2canvas from 'html2canvas';
import type { Product } from '@shared/schema';

// ── Lightweight pure-browser PDF builder (replaces jspdf) ──────────────────
// Builds a minimal valid PDF from one or more JPEG images (A4 portrait).
const A4_MM_W = 210;
const A4_MM_H = 297;
const PT_PER_MM = 72 / 25.4;
const A4_PT_W = Math.round(A4_MM_W * PT_PER_MM); // 595
const A4_PT_H = Math.round(A4_MM_H * PT_PER_MM); // 841

function buildPdfFromJpegs(pages: { jpeg: string; widthMM: number; heightMM: number; xMM: number; yMM: number }[][]): Uint8Array {
  // Each entry in `pages` is an array of images to place on that page.
  // Object ID layout (no collisions):
  //   1          = Catalog
  //   2          = Pages
  //   3..N       = Page objects          (N = 3 + pageCount - 1)
  //   N+1..M     = Content stream objs   (M = 3 + 2*pageCount - 1)
  //   M+1..      = Image XObjects
  const enc = new TextEncoder();
  const chunks: Uint8Array[] = [];
  const offsets: number[] = [];
  let pos = 0;

  const push = (s: string) => {
    const b = enc.encode(s);
    chunks.push(b);
    pos += b.length;
  };
  const pushBytes = (b: Uint8Array) => {
    chunks.push(b);
    pos += b.length;
  };

  push('%PDF-1.4\n');

  const pageCount = pages.length;

  type ImgObj = { objId: number; width: number; height: number; dataBytes: Uint8Array };
  const pageImgObjs: ImgObj[][] = pages.map(() => []);

  // First pass: decode base64 images and assign object IDs.
  // Image XObjects start at (3 + 2*pageCount) to avoid colliding with:
  //   page objects   [3 .. 3+pageCount-1]
  //   content streams [3+pageCount .. 3+2*pageCount-1]
  let nextObjId = 3 + 2 * pageCount;
  for (let pi = 0; pi < pages.length; pi++) {
    for (const img of pages[pi]) {
      const b64 = img.jpeg.replace(/^data:image\/jpeg;base64,/, '');
      const binary = atob(b64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      // Parse JPEG dimensions from SOF0/SOF2 marker
      let w = 0, h = 0;
      for (let i = 0; i < bytes.length - 8; i++) {
        if (bytes[i] === 0xFF && (bytes[i+1] === 0xC0 || bytes[i+1] === 0xC2)) {
          h = (bytes[i+5] << 8) | bytes[i+6];
          w = (bytes[i+7] << 8) | bytes[i+8];
          break;
        }
      }
      pageImgObjs[pi].push({ objId: nextObjId, width: w || 100, height: h || 100, dataBytes: bytes });
      nextObjId++;
    }
  }

  const totalObjects = nextObjId - 1;

  // Write object helper
  const startObj = (id: number) => {
    offsets[id] = pos;
    push(`${id} 0 obj\n`);
  };
  const endObj = () => push('endobj\n');

  // Object 1: Catalog
  startObj(1);
  push('<< /Type /Catalog /Pages 2 0 R >>\n');
  endObj();

  // Object 2: Pages
  startObj(2);
  const kidsStr = Array.from({ length: pageCount }, (_, i) => `${3 + i} 0 R`).join(' ');
  push(`<< /Type /Pages /Kids [${kidsStr}] /Count ${pageCount} >>\n`);
  endObj();

  // Objects 3..(3+pageCount-1): Page dictionary objects
  // Objects (3+pageCount)..(3+2*pageCount-1): Content stream objects
  for (let pi = 0; pi < pageCount; pi++) {
    const pageObjId    = 3 + pi;
    const contentObjId = 3 + pageCount + pi; // safe: no overlap with image IDs
    const imgs         = pageImgObjs[pi];
    const pageInputImgs = pages[pi];

    // Build content stream: draw each image XObject onto the page
    let streamLines = '';
    for (let ii = 0; ii < imgs.length; ii++) {
      const imgObj = imgs[ii];
      const inp    = pageInputImgs[ii];
      const xPt    = inp.xMM * PT_PER_MM;
      const yPt    = A4_PT_H - (inp.yMM * PT_PER_MM) - (inp.heightMM * PT_PER_MM);
      const wPt    = inp.widthMM * PT_PER_MM;
      const hPt    = inp.heightMM * PT_PER_MM;
      const xName  = `Im${imgObj.objId}`;
      streamLines += `q ${wPt.toFixed(3)} 0 0 ${hPt.toFixed(3)} ${xPt.toFixed(3)} ${yPt.toFixed(3)} cm /${xName} Do Q\n`;
    }
    const streamBytes = enc.encode(streamLines);

    // XObject resource dictionary entries
    const xObjEntries = imgs.map(im => `/Im${im.objId} ${im.objId} 0 R`).join(' ');

    // Write page dictionary
    startObj(pageObjId);
    push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${A4_PT_W} ${A4_PT_H}] /Contents ${contentObjId} 0 R /Resources << /XObject << ${xObjEntries} >> >> >>\n`);
    endObj();

    // Write content stream
    startObj(contentObjId);
    push(`<< /Length ${streamBytes.length} >>\n`);
    push('stream\n');
    pushBytes(streamBytes);
    push('\nendstream\n');
    endObj();
  }

  // Image XObjects (IDs start at 3+2*pageCount — guaranteed no overlap)
  for (let pi = 0; pi < pages.length; pi++) {
    for (const img of pageImgObjs[pi]) {
      startObj(img.objId);
      push(`<< /Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.dataBytes.length} >>\n`);
      push('stream\n');
      pushBytes(img.dataBytes);
      push('\nendstream\n');
      endObj();
    }
  }

  // Cross-reference table
  const xrefOffset = pos;
  push(`xref\n0 ${totalObjects + 1}\n`);
  push('0000000000 65535 f \n');
  for (let i = 1; i <= totalObjects; i++) {
    const o = offsets[i] ?? 0;
    push(`${String(o).padStart(10, '0')} 00000 n \n`);
  }
  push(`trailer\n<< /Size ${totalObjects + 1} /Root 1 0 R >>\n`);
  push(`startxref\n${xrefOffset}\n%%EOF\n`);

  // Concatenate all chunks into a single Uint8Array
  const total = chunks.reduce((s, c) => s + c.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.length; }
  return out;
}

class SimplePDF {
  private pageImages: { jpeg: string; widthMM: number; heightMM: number; xMM: number; yMM: number }[][] = [[]];
  private _pageW = A4_MM_W;
  private _pageH = A4_MM_H;

  getPageWidth() { return this._pageW; }
  getPageHeight() { return this._pageH; }

  addPage() {
    this.pageImages.push([]);
  }

  addImage(jpeg: string, _fmt: string, xMM: number, yMM: number, widthMM: number, heightMM: number) {
    this.pageImages[this.pageImages.length - 1].push({ jpeg, widthMM, heightMM, xMM, yMM });
  }

  save(filename: string) {
    const bytes = buildPdfFromJpegs(this.pageImages);
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename.endsWith('.pdf') ? filename : filename + '.pdf';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
}

let _fontCssCache: string | null = null;

const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunkSize, bytes.length)));
  }
  return btoa(binary);
};

const getCairoFontCSS = async (): Promise<string> => {
  if (_fontCssCache) return _fontCssCache;

  try {
    const cssRes = await fetch(
      'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap',
      {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
      }
    );
    let cssText = await cssRes.text();

    const urlMatches = [...cssText.matchAll(/url\((https:\/\/fonts\.gstatic\.com\/[^)]+)\)/g)];

    await Promise.all(
      urlMatches.map(async (match) => {
        const url = match[1];
        try {
          const fontRes = await fetch(url);
          const buffer = await fontRes.arrayBuffer();
          const base64 = arrayBufferToBase64(buffer);
          cssText = cssText.replace(url, `data:font/woff2;base64,${base64}`);
        } catch {}
      })
    );

    _fontCssCache = cssText;
    return cssText;
  } catch {
    return `@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');`;
  }
};

/**
 * Wraps digit sequences in an LTR <span> so html2canvas renders
 * mixed Arabic+number text correctly without double-BiDi reversal.
 */
const escHtml = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const wrapNumbers = (text: string): string =>
  escHtml(text).replace(/(\d[\d.,]*)/g,
    '<span dir="ltr" style="direction:ltr;unicode-bidi:embed;display:inline;">$1</span>');

const setRtlHtml = (el: HTMLElement, text: string) => {
  const hasArabic = /[\u0600-\u06FF]/.test(text);
  const hasDigit  = /\d/.test(text);
  if (hasArabic && hasDigit) {
    el.innerHTML = wrapNumbers(text);
  } else {
    el.textContent = text;
  }
};

const createPrintDocument = (element: HTMLElement, items: any[], details: any): HTMLElement => {
  const printDiv = document.createElement('div');
  printDiv.style.width = '210mm';
  printDiv.style.padding = '6mm 4mm';
  printDiv.style.backgroundColor = '#ffffff';
  printDiv.style.color = '#000000';
  printDiv.style.fontFamily = 'Cairo, sans-serif';
  printDiv.style.lineHeight = '1.5';
  printDiv.style.fontSize = '14px';
  printDiv.style.direction = 'rtl';
  printDiv.style.textAlign = 'right';
  printDiv.style.boxSizing = 'border-box';

  const clone = element.cloneNode(true) as HTMLElement;

  const inputs = clone.querySelectorAll('input, textarea');
  inputs.forEach(input => {
    const htmlInput = input as HTMLInputElement | HTMLTextAreaElement;
    const value = htmlInput.value;
    // Default to RTL for this Arabic app; only LTR for number inputs
    const inputType = (htmlInput as HTMLInputElement).type;
    const isRtl = inputType !== 'number' && (htmlInput.getAttribute('dir') !== 'ltr');

    const div = document.createElement('div');
    div.style.whiteSpace = 'pre-wrap';
    div.style.wordWrap = 'break-word';
    div.style.color = '#000000';
    div.style.direction = isRtl ? 'rtl' : 'ltr';
    div.style.unicodeBidi = 'embed';
    if (isRtl) div.setAttribute('dir', 'rtl');

    const computedStyle = window.getComputedStyle(htmlInput);
    div.style.fontSize = computedStyle.fontSize;
    div.style.fontWeight = computedStyle.fontWeight;
    // For number inputs always center; for RTL inputs use right; fallback from inline style
    if (!isRtl) {
      div.style.textAlign = 'center';
    } else {
      div.style.textAlign = (htmlInput as HTMLElement).style.textAlign || computedStyle.textAlign || 'right';
    }
    div.style.margin = computedStyle.margin;
    div.style.padding = computedStyle.padding;

    if (isRtl && value) {
      setRtlHtml(div, value);
    } else {
      div.textContent = value || ' ';
    }
    htmlInput.parentNode?.replaceChild(div, htmlInput);
  });

  // Rebuild the info row (date / quotation-number / customer) with pure inline styles
  // so html2canvas renders label directly above its value with no layout surprises.
  const infoRow = clone.querySelector('[data-pdf-info-row]') as HTMLElement | null;
  if (infoRow && details) {
    const cell = (label: string, value: string, borderBottom = true) => {
      const c = document.createElement('div');
      c.style.cssText = `flex:1;text-align:center;padding:0 4px;`;
      const lbl = document.createElement('div');
      lbl.style.cssText = `display:block;font-size:10px;font-weight:700;color:#64748b;margin-bottom:3px;font-family:Cairo,sans-serif;`;
      lbl.textContent = label;
      const val = document.createElement('div');
      val.style.cssText = `display:block;font-size:13px;font-weight:900;color:#0f172a;font-family:Cairo,sans-serif;${borderBottom ? 'border-bottom:2px solid #cbd5e1;padding-bottom:10px;' : ''}`;
      val.textContent = value || '—';
      c.appendChild(lbl);
      c.appendChild(val);
      return c;
    };

    const row = document.createElement('div');
    row.style.cssText = `display:flex;flex-direction:row;gap:12px;padding-top:8px;border-top:1px solid #f1f5f9;width:100%;box-sizing:border-box;`;
    row.appendChild(cell('التاريخ', details.date || '', true));
    row.appendChild(cell('عرض سعر رقم', details.quotationNumber || '', false));
    row.appendChild(cell('العميل', details.customerName || '', true));
    infoRow.parentNode?.replaceChild(row, infoRow);
  }

  const noPrint = clone.querySelectorAll('.no-print');
  noPrint.forEach(el => el.remove());

  const tables = clone.querySelectorAll('table');
  tables.forEach(table => {
    table.style.borderCollapse = 'collapse';
    table.style.width = '100%';
    table.style.direction = 'rtl';
    table.setAttribute('dir', 'rtl');

    const headerCells = table.querySelectorAll('th');
    headerCells.forEach((cell, colIdx) => {
      const element = cell as HTMLElement;
      element.style.border = '1px solid #000000';
      element.style.padding = '10px 8px';
      element.style.minHeight = '40px';
      element.style.height = '40px';
      element.style.verticalAlign = 'middle';
      // Columns 1,2,3 (الاسم، الوصف، القسم) → right-aligned; others → center
      const thAlign = [1, 2, 3].includes(colIdx) ? 'right' : 'center';
      element.style.textAlign = thAlign;
      element.style.backgroundColor = '#1e293b';
      element.style.color = '#ffffff';
      element.style.fontWeight = 'bold';
      element.style.fontSize = '12px';
      element.style.direction = 'rtl';

      // Fix child divs/spans that replaced inputs — override their black color and alignment
      element.querySelectorAll('div, span').forEach(child => {
        const el = child as HTMLElement;
        el.style.color = '#ffffff';
        el.style.fontWeight = 'bold';
        el.style.textAlign = thAlign;
        el.style.width = '100%';
        el.style.display = 'block';
      });
    });

    const dataCells = table.querySelectorAll('tbody td');
    dataCells.forEach(cell => {
      const element = cell as HTMLElement;
      element.style.border = '1px solid #000000';
      element.style.padding = '10px 8px';
      element.style.minHeight = '40px';
      element.style.height = '40px';
      element.style.verticalAlign = 'middle';
      element.style.wordWrap = 'break-word';
      element.style.whiteSpace = 'normal';
      element.style.backgroundColor = '#ffffff';
      element.style.color = '#000000';
      element.style.direction = 'rtl';
      element.setAttribute('dir', 'rtl');

      // Fix any inner content that may have mismatched direction
      const innerDivs = element.querySelectorAll('div, span');
      innerDivs.forEach(inner => {
        const el = inner as HTMLElement;
        if (!el.style.direction) {
          el.style.direction = 'rtl';
          el.style.unicodeBidi = 'embed';
        }
      });
    });

    // Process each tbody row: center specific columns, preserve number-input direction
    const tbodyRows = table.querySelectorAll('tbody tr');
    tbodyRows.forEach(row => {
      const cells = row.querySelectorAll('td');
      cells.forEach((cell, colIdx) => {
        const cellEl = cell as HTMLElement;
        const inner = cellEl.querySelector('div, span, input') as HTMLElement | null;
        const innerDir = inner?.style.direction;

        // Columns 4 & 5 are quantity & price (number inputs) — always center, ltr
        if (colIdx === 4 || colIdx === 5) {
          cellEl.style.textAlign = 'center';
          if (inner) {
            inner.style.textAlign = 'center';
            inner.style.direction = 'ltr';
            inner.setAttribute('dir', 'ltr');
          }
        } else if ([1, 2, 3].includes(colIdx)) {
          // Name, description, category — right-aligned RTL
          cellEl.style.textAlign = 'right';
          if (inner) {
            inner.style.textAlign = 'right';
            if (!innerDir || innerDir === 'ltr') {
              inner.style.direction = 'rtl';
              inner.setAttribute('dir', 'rtl');
            }
          }
        }
      });
    });

    // Style tfoot (grand total row) to match on-screen appearance
    const tfootCells = Array.from(table.querySelectorAll('tfoot td'));
    const lastTfootIdx = tfootCells.length - 1;
    tfootCells.forEach((cell, idx) => {
      const element = cell as HTMLElement;
      element.style.border = '1px solid #000000';
      element.style.padding = '10px 8px';
      element.style.minHeight = '40px';
      element.style.height = '40px';
      element.style.verticalAlign = 'middle';
      element.style.backgroundColor = '#0f172a';
      element.style.color = '#ffffff';
      element.style.fontWeight = 'bold';
      if (idx === lastTfootIdx - 1) {
        element.style.backgroundColor = '#1e3a8a';
        element.style.fontSize = '14px';
        element.style.fontWeight = '900';
        element.style.textAlign = 'center';
      }
    });
  });

  const allElements = clone.querySelectorAll('*');
  allElements.forEach(el => {
    const element = el as HTMLElement;
    element.style.boxShadow = 'none';
  });

  // Fix flex and grid containers - apply styles inline since html2canvas ignores Tailwind classes
  const allCloned = clone.querySelectorAll('*');
  allCloned.forEach(container => {
    const el = container as HTMLElement;
    if (!el.classList) return;
    if (el.classList.contains('flex') || el.classList.contains('inline-flex')) {
      el.style.display = 'flex';
      if (el.classList.contains('items-center')) el.style.alignItems = 'center';
      if (el.classList.contains('items-start')) el.style.alignItems = 'flex-start';
      if (el.classList.contains('items-end')) el.style.alignItems = 'flex-end';
      if (el.classList.contains('justify-center')) el.style.justifyContent = 'center';
      if (el.classList.contains('justify-between')) el.style.justifyContent = 'space-between';
      if (el.classList.contains('justify-end')) el.style.justifyContent = 'flex-end';
      if (el.classList.contains('gap-1')) el.style.gap = '4px';
      if (el.classList.contains('gap-2')) el.style.gap = '8px';
      if (el.classList.contains('gap-3')) el.style.gap = '12px';
      if (el.classList.contains('gap-4')) el.style.gap = '16px';
      if (el.classList.contains('gap-6')) el.style.gap = '24px';
      if (el.classList.contains('gap-8')) el.style.gap = '32px';
      if (el.classList.contains('flex-wrap')) el.style.flexWrap = 'wrap';
      if (el.classList.contains('flex-1')) el.style.flex = '1';
      if (el.classList.contains('flex-shrink-0')) el.style.flexShrink = '0';
    }
    // Fix grid containers — html2canvas does NOT support CSS Grid,
    // so we convert grids to flexbox with equal-width children.
    if (el.classList.contains('grid')) {
      el.style.display = 'flex';
      el.style.flexDirection = 'row';
      if (el.classList.contains('gap-1')) el.style.gap = '4px';
      if (el.classList.contains('gap-2')) el.style.gap = '8px';
      if (el.classList.contains('gap-3')) el.style.gap = '12px';
      if (el.classList.contains('gap-4')) el.style.gap = '16px';
      if (el.classList.contains('gap-6')) el.style.gap = '24px';
      // Give every direct child an equal flex share
      let cols = 1;
      if (el.classList.contains('grid-cols-2')) cols = 2;
      if (el.classList.contains('grid-cols-3')) cols = 3;
      if (el.classList.contains('grid-cols-4')) cols = 4;
      const gap = el.classList.contains('gap-1') ? 4
                : el.classList.contains('gap-2') ? 8
                : el.classList.contains('gap-3') ? 12
                : el.classList.contains('gap-4') ? 16
                : el.classList.contains('gap-6') ? 24 : 0;
      Array.from(el.children).forEach(child => {
        const w = `calc((100% - ${gap * (cols - 1)}px) / ${cols})`;
        (child as HTMLElement).style.flex = `0 0 ${w}`;
        (child as HTMLElement).style.width = w;
        (child as HTMLElement).style.boxSizing = 'border-box';
      });
    }
    // Fix text-align utilities
    if (el.classList.contains('text-center')) el.style.textAlign = 'center';
    if (el.classList.contains('text-right'))  el.style.textAlign = 'right';
    if (el.classList.contains('text-left'))   el.style.textAlign = 'left';
    // Fix space-y utilities (vertical spacing between children)
    if (el.classList.contains('space-y-1')) {
      Array.from(el.children).forEach((child, i) => {
        if (i > 0) (child as HTMLElement).style.marginTop = '4px';
      });
    }
    if (el.classList.contains('space-y-2')) {
      Array.from(el.children).forEach((child, i) => {
        if (i > 0) (child as HTMLElement).style.marginTop = '8px';
      });
    }
    if (el.classList.contains('space-y-4')) {
      Array.from(el.children).forEach((child, i) => {
        if (i > 0) (child as HTMLElement).style.marginTop = '16px';
      });
    }
  });

  // Fix item images in table rows - convert label wrappers to divs and apply inline styles
  // so html2canvas can correctly render uploaded product images.
  // Only target labels inside table cells (not text labels like "التاريخ" in the header).
  const itemImageLabels = clone.querySelectorAll('td label');
  itemImageLabels.forEach(label => {
    const img = label.querySelector('img');

    if (!img) {
      // No image - replace label with empty placeholder cell
      const emptyDiv = document.createElement('div');
      emptyDiv.style.cssText = `
        display: block;
        width: 120px;
        height: 120px;
        border-radius: 6px;
        border: 1px dashed #cbd5e1;
        margin: 0 auto;
        background: #f8fafc;
      `;
      label.parentNode?.replaceChild(emptyDiv, label);
      return;
    }

    // Replace label with a div so form-element styling doesn't interfere
    const div = document.createElement('div');
    div.style.cssText = `
      display: block;
      width: 120px;
      height: 120px;
      overflow: hidden;
      border-radius: 6px;
      border: 1px solid #e2e8f0;
      margin: 0 auto;
      flex-shrink: 0;
    `;

    // Clone the img and set explicit inline dimensions
    const imgClone = img.cloneNode(true) as HTMLImageElement;
    imgClone.style.cssText = `
      width: 120px;
      height: 120px;
      object-fit: cover;
      display: block;
    `;
    div.appendChild(imgClone);
    label.parentNode?.replaceChild(div, label);
  });

  // Remove all SVG elements - html2canvas cannot reliably align SVGs with inline text
  // We rebuild the contact footer section manually below using plain text + Unicode
  const svgElements = clone.querySelectorAll('svg');
  svgElements.forEach(svg => {
    svg.parentNode?.removeChild(svg);
  });

  // Rebuild the contact footer if details are provided, replacing the cloned version
  // Find the footer section (last border-t section in the clone) and replace its inner HTML
  if (details && (details.phone || details.email || details.website)) {
    // Find all border-t divs and take the last one (contact section)
    const borderSections = clone.querySelectorAll('[class*="border-t"]');
    const contactSection = borderSections[borderSections.length - 1] as HTMLElement | undefined;

    if (contactSection) {
      contactSection.innerHTML = '';
      contactSection.style.borderTop = '1px solid #e2e8f0';
      contactSection.style.paddingTop = '8px';
      contactSection.style.textAlign = 'center';

      const companyName = document.createElement('div');
      companyName.textContent = details.companyNameAr || 'مؤسسة ومشاتل القادري الزراعية';
      companyName.style.fontSize = '10px';
      companyName.style.fontWeight = 'bold';
      companyName.style.color = '#0f172a';
      companyName.style.marginBottom = '6px';
      contactSection.appendChild(companyName);

      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.alignItems = 'center';
      row.style.justifyContent = 'center';
      row.style.gap = '20px';
      row.style.direction = 'ltr';
      row.style.fontSize = '10px';
      row.style.color = '#475569';
      row.style.fontFamily = 'Cairo, Arial, sans-serif';

      const makeItem = (icon: string, text: string) => {
        const item = document.createElement('span');
        item.style.display = 'inline-flex';
        item.style.alignItems = 'center';
        item.style.gap = '3px';
        item.style.lineHeight = '1.4';

        const iconSpan = document.createElement('span');
        iconSpan.textContent = icon;
        iconSpan.style.display = 'inline-block';
        iconSpan.style.lineHeight = '1';
        iconSpan.style.fontSize = '10px';
        iconSpan.style.fontFamily = 'Arial, sans-serif';

        const textSpan = document.createElement('span');
        textSpan.textContent = text;
        textSpan.style.fontWeight = '600';

        item.appendChild(iconSpan);
        item.appendChild(textSpan);
        return item;
      };

      if (details.phone) row.appendChild(makeItem('☎', details.phone));
      if (details.email) row.appendChild(makeItem('✉', details.email));
      if (details.website) row.appendChild(makeItem('⊕', details.website));

      contactSection.appendChild(row);
    }
  }

  printDiv.appendChild(clone);
  return printDiv;
};

const createPageMiniHeader = (details: any, logoSrc: string): HTMLElement => {
  const wrapper = document.createElement('div');
  wrapper.style.width = '210mm';
  wrapper.style.padding = '3mm 4mm 2mm';
  wrapper.style.backgroundColor = '#ffffff';
  wrapper.style.direction = 'rtl';
  wrapper.style.boxSizing = 'border-box';
  wrapper.style.borderBottom = '2px solid #e2e8f0';
  wrapper.style.display = 'flex';
  wrapper.style.alignItems = 'center';
  wrapper.style.gap = '10px';
  wrapper.style.fontFamily = 'Cairo, sans-serif';

  if (logoSrc) {
    const logo = document.createElement('img');
    logo.src = logoSrc;
    logo.crossOrigin = 'anonymous';
    logo.style.width = '45px';
    logo.style.height = '45px';
    logo.style.objectFit = 'contain';
    logo.style.flexShrink = '0';
    wrapper.appendChild(logo);
  }

  const textDiv = document.createElement('div');
  textDiv.style.flex = '1';

  const nameAr = document.createElement('div');
  nameAr.style.fontSize = '13px';
  nameAr.style.fontWeight = 'bold';
  nameAr.style.color = '#1e293b';
  nameAr.textContent = details.companyNameAr || 'مؤسسة ومشاتل القادري الزراعية';

  const nameEn = document.createElement('div');
  nameEn.style.fontSize = '9px';
  nameEn.style.color = '#64748b';
  nameEn.style.direction = 'ltr';
  nameEn.style.textAlign = 'left';
  nameEn.textContent = details.companyNameEn || 'Al-Qadri Agricultural Establishment';

  textDiv.appendChild(nameAr);
  textDiv.appendChild(nameEn);
  wrapper.appendChild(textDiv);

  return wrapper;
};

const PDF_OVERLAY_ATTR = 'data-pdf-loading-overlay';

/**
 * Shows a white loading overlay over the entire page while PDF is being generated.
 * The print element is placed at z-index:1 (below the overlay) so the user
 * doesn't see it flash, but it IS fully visible to html2canvas.
 * In onclone the overlay is hidden so it doesn't appear in the captured canvas.
 */
const showPdfLoadingOverlay = (): HTMLElement => {
  const overlay = document.createElement('div');
  overlay.setAttribute(PDF_OVERLAY_ATTR, 'true');
  overlay.style.cssText =
    'position:fixed;inset:0;background:rgba(255,255,255,0.97);z-index:99999;' +
    'display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px;direction:rtl;';
  overlay.innerHTML =
    '<style>@keyframes __pdfSpin{to{transform:rotate(360deg)}}</style>' +
    '<div style="width:38px;height:38px;border:3px solid #e2e8f0;border-top-color:#16a34a;' +
    'border-radius:50%;animation:__pdfSpin 0.8s linear infinite;"></div>' +
    '<div style="font-family:Cairo,Arial,sans-serif;font-size:15px;color:#1e293b;font-weight:600;">' +
    'جاري إنشاء PDF...</div>';
  document.body.appendChild(overlay);
  return overlay;
};

const renderToCanvas = async (
  el: HTMLElement,
  opts: { hideSelectors?: string[] } = {}
): Promise<HTMLCanvasElement> => {
  const fontCss = await getCairoFontCSS();
  if (!document.getElementById('__pdf_cairo_font__')) {
    const s = document.createElement('style');
    s.id = '__pdf_cairo_font__';
    s.textContent = fontCss;
    document.head.appendChild(s);
  }
  try { await document.fonts.ready; } catch {}

  // The element is placed at position:fixed top:0 left:0 so scrollX/scrollY must be 0.
  return html2canvas(el, {
    scale: 3,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    allowTaint: true,
    imageTimeout: 15000,
    scrollX: 0,
    scrollY: 0,
    windowWidth: Math.round(210 * 96 / 25.4),
    onclone: (doc: Document) => {
      doc.documentElement.classList.remove('dark');
      doc.documentElement.setAttribute('dir', 'rtl');
      doc.documentElement.style.direction = 'rtl';
      const style = doc.createElement('style');
      style.textContent = fontCss + '\n* { font-family: "Cairo", Arial, sans-serif !important; }';
      doc.head.appendChild(style);
      // Hide the loading overlay in the clone - it must NOT appear in the PDF
      (doc.querySelectorAll(`[${PDF_OVERLAY_ATTR}]`) as NodeListOf<HTMLElement>).forEach(el => {
        el.style.display = 'none';
      });
      // Hide any additional selectors requested by the caller
      opts.hideSelectors?.forEach(sel => {
        (doc.querySelectorAll(sel) as NodeListOf<HTMLElement>).forEach(el => {
          el.style.display = 'none';
        });
      });
    },
  });
};

export const exportNoHeaderToPDF = async (elementId: string, filename: string) => {
  const element = document.getElementById(elementId);
  if (!element) return;

  const overlay = showPdfLoadingOverlay();
  let captureWrapper: HTMLElement | null = null;

  try {
    // Clone the live element so we don't modify the actual DOM
    const cloneEl = element.cloneNode(true) as HTMLElement;

    // Hide no-print elements in the clone
    cloneEl.querySelectorAll('.no-print').forEach(el => {
      (el as HTMLElement).style.display = 'none';
    });

    // Replace every <input> with a <div> showing its value as static text.
    // html2canvas does not reliably render <input> values, so we must convert
    // them to plain elements before capturing.
    // Collect live values BEFORE operating on the clone so indices match.
    const liveInputs = Array.from(element.querySelectorAll<HTMLInputElement>('input'));
    const liveTextareas = Array.from(element.querySelectorAll<HTMLTextAreaElement>('textarea'));

    Array.from(cloneEl.querySelectorAll<HTMLInputElement>('input')).forEach((input, idx) => {
      const val = liveInputs[idx]?.value ?? input.getAttribute('value') ?? '';
      const cs = window.getComputedStyle(input);
      const div = document.createElement('div');
      div.textContent = val || input.placeholder || '';
      div.style.cssText =
        `font-size:${cs.fontSize};font-weight:${cs.fontWeight};color:${val ? cs.color : '#9ca3af'};` +
        `direction:${cs.direction};text-align:${cs.textAlign};` +
        `width:100%;word-break:break-word;white-space:pre-wrap;padding:${cs.paddingTop} 0;` +
        `background:transparent;line-height:${cs.lineHeight};font-family:${cs.fontFamily};`;
      input.replaceWith(div);
    });

    // Replace every <textarea> with a <div> showing its value.
    Array.from(cloneEl.querySelectorAll<HTMLTextAreaElement>('textarea')).forEach((textarea, idx) => {
      const val = liveTextareas[idx]?.value ?? textarea.textContent ?? '';
      const cs = window.getComputedStyle(textarea);
      const div = document.createElement('div');
      div.textContent = val || textarea.placeholder || '';
      div.style.cssText =
        `font-size:${cs.fontSize};font-weight:${cs.fontWeight};color:${val ? cs.color : '#9ca3af'};` +
        `direction:${cs.direction};text-align:${cs.textAlign};` +
        `width:100%;word-break:break-word;white-space:pre-wrap;` +
        `background:transparent;line-height:${cs.lineHeight};font-family:${cs.fontFamily};`;
      textarea.replaceWith(div);
    });

    // Fix overflow:hidden on all inner elements — prevents text clipping in PDF.
    cloneEl.querySelectorAll<HTMLElement>('*').forEach(el => {
      const cs = window.getComputedStyle(el);
      if (cs.overflow === 'hidden' || cs.overflowX === 'hidden' || cs.overflowY === 'hidden') {
        el.style.overflow = 'visible';
      }
    });

    // ── Convert CSS Grid → Flexbox so html2canvas renders columns correctly ──
    cloneEl.querySelectorAll<HTMLElement>('*').forEach(el => {
      if (!el.classList) return;
      // Convert grid layouts to flex (html2canvas doesn't support CSS Grid)
      if (el.classList.contains('grid')) {
        el.style.display = 'flex';
        el.style.flexDirection = 'row';
        let cols = 1;
        if (el.classList.contains('grid-cols-2')) cols = 2;
        if (el.classList.contains('grid-cols-3')) cols = 3;
        if (el.classList.contains('grid-cols-4')) cols = 4;
        const gapPx = el.classList.contains('gap-2') ? 8
          : el.classList.contains('gap-3') ? 12
          : el.classList.contains('gap-4') ? 16
          : el.classList.contains('gap-6') ? 24
          : el.classList.contains('gap-8') ? 32 : 0;
        if (gapPx) el.style.gap = `${gapPx}px`;
        Array.from(el.children).forEach(child => {
          const w = `calc((100% - ${gapPx * (cols - 1)}px) / ${cols})`;
          (child as HTMLElement).style.flex = `0 0 ${w}`;
          (child as HTMLElement).style.width = w;
          (child as HTMLElement).style.boxSizing = 'border-box';
        });
      }
      // Fix flex utilities
      if (el.classList.contains('flex') || el.classList.contains('inline-flex')) {
        el.style.display = 'flex';
        if (el.classList.contains('items-center')) el.style.alignItems = 'center';
        if (el.classList.contains('items-start'))  el.style.alignItems = 'flex-start';
        if (el.classList.contains('justify-center'))  el.style.justifyContent = 'center';
        if (el.classList.contains('justify-between')) el.style.justifyContent = 'space-between';
        if (el.classList.contains('justify-end'))     el.style.justifyContent = 'flex-end';
        if (el.classList.contains('flex-col'))        el.style.flexDirection = 'column';
        if (el.classList.contains('flex-1'))          el.style.flex = '1';
        if (el.classList.contains('flex-shrink-0'))   el.style.flexShrink = '0';
        if (el.classList.contains('flex-wrap'))       el.style.flexWrap = 'wrap';
        const fg = el.classList.contains('gap-1') ? 4 : el.classList.contains('gap-2') ? 8
          : el.classList.contains('gap-3') ? 12 : el.classList.contains('gap-4') ? 16
          : el.classList.contains('gap-6') ? 24 : el.classList.contains('gap-8') ? 32 : -1;
        if (fg >= 0) el.style.gap = `${fg}px`;
      }
      // Text alignment
      if (el.classList.contains('text-center')) el.style.textAlign = 'center';
      if (el.classList.contains('text-right'))  el.style.textAlign = 'right';
      if (el.classList.contains('text-left'))   el.style.textAlign = 'left';
    });

    // ── Force RTL direction on the meta row labels and values ──
    cloneEl.querySelectorAll<HTMLElement>('[style*="accentColor"], [class*="tracking-wide"]').forEach(el => {
      el.style.direction = 'rtl';
      el.style.textAlign = 'right';
    });

    // Set clean PDF-ready styles - explicit width so html2canvas has a fixed layout width
    const PDF_WIDTH_PX = Math.round(210 * 96 / 25.4); // 210mm at 96dpi ≈ 794px
    cloneEl.style.cssText = cloneEl.style.cssText +
      `;width:${PDF_WIDTH_PX}px;min-height:auto;height:auto;flex:none;` +
      'background:#ffffff;background-color:#ffffff;color:#1e293b;' +
      'box-shadow:none;border:none;border-radius:0;overflow:visible;padding:20px;';

    // Place clone fully visible in the document at z-index:1
    // The loading overlay sits at z-index:99999 so the user never sees this clone,
    // but html2canvas (which captures the cloned document) WILL see it correctly.
    captureWrapper = document.createElement('div');
    captureWrapper.style.cssText =
      'position:fixed;top:0;left:0;z-index:1;pointer-events:none;overflow:visible;' +
      `width:${PDF_WIDTH_PX}px;direction:rtl;`;
    captureWrapper.appendChild(cloneEl);
    document.body.appendChild(captureWrapper);

    // Wait for a layout pass and any images to settle
    await new Promise(resolve => setTimeout(resolve, 500));

    // Bake computed text/background colors into inline styles so html2canvas
    // receives explicit colors regardless of how CSS custom-properties or
    // Tailwind dark-mode variants resolve inside its internal clone.
    Array.from(cloneEl.querySelectorAll<HTMLElement>('*')).forEach(el => {
      const cs = window.getComputedStyle(el);
      const color = cs.color;
      const bg = cs.backgroundColor;
      if (color && color !== 'rgba(0, 0, 0, 0)') el.style.color = color;
      if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
        el.style.backgroundColor = bg;
      }
    });

    const canvas = await renderToCanvas(cloneEl);

    document.body.removeChild(captureWrapper);
    captureWrapper = null;
    document.body.removeChild(overlay);

    if (!canvas || canvas.width === 0 || canvas.height === 0) {
      console.error('No-header PDF: canvas is empty');
      return;
    }

    // Build PDF pages
    const pdf = new SimplePDF();
    const pdfWidth = pdf.getPageWidth();
    const pdfHeight = pdf.getPageHeight();
    const canvasPixelsPerMM = canvas.width / pdfWidth;
    const fullPageHeightPx = pdfHeight * canvasPixelsPerMM;

    let sourceY = 0;
    let pageIndex = 0;

    while (sourceY < canvas.height) {
      if (pageIndex > 0) pdf.addPage();

      const remainingPx = canvas.height - sourceY;
      if (remainingPx <= 0) break;

      const sliceHeightPx = Math.min(remainingPx, fullPageHeightPx);
      if (sliceHeightPx <= 0) break;

      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = Math.round(sliceHeightPx);
      const ctx = pageCanvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
        ctx.drawImage(
          canvas,
          0, Math.round(sourceY), canvas.width, Math.round(sliceHeightPx),
          0, 0, canvas.width, Math.round(sliceHeightPx)
        );
      }

      const imgData = pageCanvas.toDataURL('image/jpeg', 0.95);
      const pageHeightMM = sliceHeightPx / canvasPixelsPerMM;
      pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pageHeightMM);

      sourceY += sliceHeightPx;
      pageIndex++;
    }

    pdf.save(`${filename}.pdf`);
  } catch (error) {
    if (captureWrapper?.parentNode) document.body.removeChild(captureWrapper);
    if (overlay?.parentNode) document.body.removeChild(overlay);
    console.error('Failed to generate no-header PDF:', error);
  }
};

export const exportToPDF = async (
  elementId: string,
  filename: string,
  items?: any[],
  details?: any,
  logoSrc?: string
) => {
  const element = document.getElementById(elementId);
  if (!element) return;

  const overlay = showPdfLoadingOverlay();
  let captureWrapper: HTMLElement | null = null;
  let miniWrapper: HTMLElement | null = null;

  try {
    await getCairoFontCSS();

    const pdf = new SimplePDF();
    const pdfWidth = pdf.getPageWidth();
    const pdfHeight = pdf.getPageHeight();
    const marginX = 2;
    const marginY = 2;
    const imgWidth = pdfWidth - marginX * 2;

    // Build the print-ready document clone (inputs → plain text, SVGs removed, etc.)
    const printDoc = createPrintDocument(element, items || [], details || {});
    printDoc.style.direction = 'rtl';
    printDoc.setAttribute('dir', 'rtl');

    // Place printDoc FULLY VISIBLE at z-index:1 (below the loading overlay at z-index:99999).
    // The user sees only the spinner. html2canvas clones the entire document and sees
    // printDoc as fully rendered — no visibility:hidden tricks needed.
    captureWrapper = document.createElement('div');
    captureWrapper.style.cssText =
      'position:fixed;top:0;left:0;width:210mm;z-index:1;pointer-events:none;overflow:visible;';
    captureWrapper.appendChild(printDoc);
    document.body.appendChild(captureWrapper);

    // Give the browser time to lay out printDoc and load any images inside it
    await new Promise(resolve => setTimeout(resolve, 500));

    // Measure table row boundaries for smart page-break snapping
    // (html2canvas scale:3 → multiply CSS pixels by 3 to get canvas pixels)
    const HTML2CANVAS_SCALE = 3;
    const printDocRect = printDoc.getBoundingClientRect();
    const rowBreaksCx = new Set<number>();
    rowBreaksCx.add(0);
    printDoc.querySelectorAll('tr').forEach(row => {
      const r = row.getBoundingClientRect();
      rowBreaksCx.add(Math.round((r.top    - printDocRect.top) * HTML2CANVAS_SCALE));
      rowBreaksCx.add(Math.round((r.bottom - printDocRect.top) * HTML2CANVAS_SCALE));
    });
    const sortedRowBreaks = Array.from(rowBreaksCx).sort((a, b) => a - b);

    const findRowCutPoint = (startY: number, maxY: number): number => {
      let best = -1;
      for (const bp of sortedRowBreaks) {
        if (bp > startY && bp <= maxY) best = bp;
      }
      return best > 0 ? best : maxY;
    };

    // Capture — the overlay is automatically hidden inside the clone by renderToCanvas's onclone
    const mainCanvas = await renderToCanvas(printDoc);
    document.body.removeChild(captureWrapper);
    captureWrapper = null;

    if (!mainCanvas || mainCanvas.width === 0 || mainCanvas.height === 0) {
      console.error('PDF generation failed: canvas is empty');
      document.body.removeChild(overlay);
      return;
    }

    // Render mini-header for page 2+ (also placed at z-index:1, overlay hides it)
    let miniHeaderCanvas: HTMLCanvasElement | null = null;
    let miniHeaderHeightMM = 0;

    if (logoSrc || details) {
      const miniHeader = createPageMiniHeader(details || {}, logoSrc || '');
      miniWrapper = document.createElement('div');
      miniWrapper.style.cssText =
        'position:fixed;top:0;left:0;width:210mm;z-index:1;pointer-events:none;overflow:visible;';
      miniWrapper.appendChild(miniHeader);
      document.body.appendChild(miniWrapper);
      await new Promise(resolve => setTimeout(resolve, 150));

      miniHeaderCanvas = await renderToCanvas(miniHeader);
      document.body.removeChild(miniWrapper);
      miniWrapper = null;

      if (miniHeaderCanvas && miniHeaderCanvas.width > 0) {
        miniHeaderHeightMM = (miniHeaderCanvas.height * imgWidth) / miniHeaderCanvas.width;
      }
    }

    document.body.removeChild(overlay);

    // Slice canvas into A4 pages
    const canvasPixelsPerMM = mainCanvas.width / imgWidth;
    const fullPageHeightPx = (pdfHeight - marginY * 2) * canvasPixelsPerMM;
    const miniHeaderHeightPx = miniHeaderCanvas
      ? (miniHeaderCanvas.height * mainCanvas.width) / miniHeaderCanvas.width
      : 0;

    const contentHeightPage1Px = fullPageHeightPx;
    const contentHeightSubsequentPx = Math.max(fullPageHeightPx - miniHeaderHeightPx, 100);

    let sourceY = 0;
    let pageIndex = 0;

    while (sourceY < mainCanvas.height) {
      if (pageIndex > 0) pdf.addPage('a4');

      let contentStartY = marginY;

      if (pageIndex > 0 && miniHeaderCanvas) {
        const miniImgData = miniHeaderCanvas.toDataURL('image/jpeg', 0.98);
        pdf.addImage(miniImgData, 'JPEG', marginX, marginY, imgWidth, miniHeaderHeightMM);
        contentStartY = marginY + miniHeaderHeightMM;
      }

      const availableContentPx = pageIndex === 0 ? contentHeightPage1Px : contentHeightSubsequentPx;
      const remainingPx = mainCanvas.height - sourceY;
      if (remainingPx <= 0) break;

      const sliceHeightPx = remainingPx <= availableContentPx
        ? remainingPx
        : findRowCutPoint(sourceY, sourceY + availableContentPx) - sourceY;

      if (sliceHeightPx <= 0) break;

      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = mainCanvas.width;
      pageCanvas.height = Math.round(sliceHeightPx);
      const ctx = pageCanvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
        ctx.drawImage(
          mainCanvas,
          0, Math.round(sourceY), mainCanvas.width, Math.round(sliceHeightPx),
          0, 0, mainCanvas.width, Math.round(sliceHeightPx)
        );
      }

      const pageImgData = pageCanvas.toDataURL('image/jpeg', 0.98);
      const pageHeightMM = sliceHeightPx / canvasPixelsPerMM;
      pdf.addImage(pageImgData, 'JPEG', marginX, contentStartY, imgWidth, pageHeightMM);

      sourceY += sliceHeightPx;
      pageIndex++;
    }

    pdf.save(`${filename}.pdf`);
  } catch (error) {
    if (captureWrapper?.parentNode) document.body.removeChild(captureWrapper);
    if (miniWrapper?.parentNode) document.body.removeChild(miniWrapper);
    if (overlay?.parentNode) document.body.removeChild(overlay);
    console.error('Failed to generate PDF:', error);
  }
};

// ─── Catalog PDF Export ─────────────────────────────────────────────────────

const COMPANY_PHONE = '00962777772211';
const CURRENCY = 'دينار أردني';
const FONT_URL = 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap';

const loadImageAsDataUrl = (src: string): Promise<string> =>
  new Promise(resolve => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0);
      resolve(c.toDataURL('image/jpeg', 0.92));
    };
    img.onerror = () => resolve('');
    img.src = src;
  });

const mkEl = (tag: string, css: string, text?: string): HTMLElement => {
  const e = document.createElement(tag);
  e.style.cssText = css;
  if (text !== undefined) e.textContent = text;
  return e;
};

const ensureCairoFont = async () => {
  if (!document.getElementById('cairo-font-link')) {
    const link = document.createElement('link');
    link.id = 'cairo-font-link';
    link.rel = 'stylesheet';
    link.href = FONT_URL;
    document.head.appendChild(link);
  }
  try {
    await Promise.all([
      document.fonts.load('400 16px Cairo'),
      document.fonts.load('700 16px Cairo'),
      document.fonts.load('900 16px Cairo'),
    ]);
    await document.fonts.ready;
  } catch {
    await new Promise(r => setTimeout(r, 1000));
  }
  // Pre-warm the base64 font cache so it's ready for html2canvas cloned documents
  await getCairoFontCSS();
};

// ── Page-aware catalog layout constants ────────────────────────────────────
const A4_W   = Math.round(210 * 96 / 25.4); // 794px
const A4_H   = Math.round(297 * 96 / 25.4); // 1122px
const C_PAD  = 18;   // horizontal + vertical page padding
const C_GAP  = 12;   // gap between cards/rows
const COLS   = 3;    // 3 cards per row
const C_COL  = Math.floor((A4_W - C_PAD * 2 - C_GAP * (COLS - 1)) / COLS); // ~244px

const CARD_IMG_H  = 163;  // tall portrait-style image
const CARD_INFO_H = 115;  // name + description + price
const CARD_BAR_H  = 5;
const CARD_H      = CARD_BAR_H + CARD_IMG_H + CARD_INFO_H; // 283px
const ROW_H       = CARD_H + C_GAP;                        // 295px
const CAT_H       = 46;   // category section header
const MAIN_HDR_H  = 178;  // page 1 header + info bar
const FOOTER_H    = 44;
const PAGE1_AVAIL = A4_H - MAIN_HDR_H - FOOTER_H - C_PAD * 2;
const PAGEN_AVAIL = A4_H - FOOTER_H - C_PAD * 2;

const CATEGORY_STYLES: Record<string, { bar: string; header: string; text: string; badge: string }> = {
  "أشجار":       { bar: '#2d6a4f,#52b788', header: '#0d4a2e', text: '#d1fae5', badge: '#bbf7d0' },
  "شجيرات":      { bar: '#166534,#4ade80', header: '#14532d', text: '#dcfce7', badge: '#a7f3d0' },
  "ورود":        { bar: '#9f1239,#fb7185', header: '#881337', text: '#fce7f3', badge: '#fbcfe8' },
  "نباتات زينة": { bar: '#5b21b6,#a78bfa', header: '#4c1d95', text: '#ede9fe', badge: '#ddd6fe' },
  "متنوعة":      { bar: '#374151,#9ca3af', header: '#1f2937', text: '#f3f4f6', badge: '#e5e7eb' },
};

// ── Types ──────────────────────────────────────────────────────────────────
type CatItem  = { type: 'cat'; label: string; count: number };
type RowItem  = { type: 'row'; cards: Product[] };
type PageItem = CatItem | RowItem;

// ── Chunk helper ──────────────────────────────────────────────────────────
function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

// Canonical category order for the catalog
const CATALOG_CAT_ORDER = ['أشجار', 'شجيرات', 'ورود', 'نباتات زينة'];

// ── Build flat item list from products ────────────────────────────────────
function buildItemList(products: Product[]): PageItem[] {
  const items: PageItem[] = [];
  const grouped: Record<string, Product[]> = {};

  for (const p of products) {
    const cat = p.category || '';
    if (cat) {
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(p);
    }
  }

  // Sort categories: known order first, then any extra categories alphabetically
  const knownCats = Object.keys(grouped);
  const sortedCats = [
    ...CATALOG_CAT_ORDER.filter(c => knownCats.includes(c)),
    ...knownCats.filter(c => !CATALOG_CAT_ORDER.includes(c)).sort(),
  ];

  const misc = products.filter(p => !p.category);

  for (const cat of sortedCats) {
    items.push({ type: 'cat', label: cat, count: grouped[cat].length });
    for (const row of chunk(grouped[cat], COLS)) items.push({ type: 'row', cards: row });
  }
  if (misc.length) {
    items.push({ type: 'cat', label: 'متنوعة', count: misc.length });
    for (const row of chunk(misc, COLS)) items.push({ type: 'row', cards: row });
  }
  return items;
}

// ── Page layout: assign items to pages ───────────────────────────────────
function assignToPages(items: PageItem[]): PageItem[][] {
  const pages: PageItem[][] = [[]];
  let avail = PAGE1_AVAIL;
  let used  = 0;

  // accounting heights (each item's visual height + the flex gap that follows it)
  const hCat = CAT_H + C_GAP;
  const hRow = ROW_H; // ROW_H already = CARD_H + C_GAP

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const h    = item.type === 'cat' ? hCat : hRow;

    if (item.type === 'cat') {
      // Ensure cat header + ≥1 row stay together on same page
      const nextH = i + 1 < items.length && items[i + 1].type === 'row' ? hRow : 0;
      if (used > 0 && used + h + nextH > avail) {
        pages.push([]);
        avail = PAGEN_AVAIL;
        used  = 0;
      }
    } else {
      if (used + h > avail) {
        pages.push([]);
        avail = PAGEN_AVAIL;
        used  = 0;
      }
    }
    pages[pages.length - 1].push(item);
    used += h;
  }
  return pages;
}

// ── Build one card element ────────────────────────────────────────────────
async function buildCard(product: Product): Promise<HTMLElement> {
  const s = CATEGORY_STYLES[product.category || ''] || CATEGORY_STYLES['متنوعة'];

  // Outer card wrapper — no overflow:hidden so text is never clipped
  const card = document.createElement('div');
  card.style.cssText = `
    width:${C_COL}px;
    background:#ffffff;
    border-radius:16px;
    border:1.5px solid #d4e9da;
    box-shadow:0 4px 14px rgba(0,0,0,0.10);
    display:block;
    flex-shrink:0;
    overflow:hidden;
  `;

  // ── 1. Top accent bar ──────────────────────────────────────────────────
  const bar = document.createElement('div');
  bar.style.cssText = `height:${CARD_BAR_H}px;background:linear-gradient(90deg,${s.bar});display:block;`;
  card.appendChild(bar);

  // ── 2. Image ───────────────────────────────────────────────────────────
  const imgBox = document.createElement('div');
  imgBox.style.cssText = `
    width:${C_COL}px;
    height:${CARD_IMG_H}px;
    overflow:hidden;
    background:linear-gradient(160deg,#e8f5e9 0%,#c8e6c9 100%);
    display:block;
    position:relative;
  `;

  if (product.imageUrl) {
    const data = await loadImageAsDataUrl(product.imageUrl);
    if (data) {
      const img = document.createElement('img') as HTMLImageElement;
      img.src = data;
      img.style.cssText = `width:${C_COL}px;height:${CARD_IMG_H}px;object-fit:cover;display:block;`;
      imgBox.appendChild(img);
    } else {
      const ph = document.createElement('div');
      ph.style.cssText = 'font-size:52px;line-height:1;padding:60px 0;text-align:center;';
      ph.textContent = '🌿';
      imgBox.appendChild(ph);
    }
  } else {
    const ph = document.createElement('div');
    ph.style.cssText = 'font-size:52px;line-height:1;padding:60px 0;text-align:center;';
    ph.textContent = '🌿';
    imgBox.appendChild(ph);
  }

  // Category badge overlaid bottom-right of image
  if (product.category) {
    const catBadge = document.createElement('div');
    catBadge.style.cssText = `
      position:absolute;
      bottom:7px;
      right:7px;
      background:${s.header};
      color:#ffffff;
      font-size:8.5px;
      font-weight:700;
      padding:3px 9px;
      border-radius:20px;
      box-shadow:0 2px 6px rgba(0,0,0,0.28);
      direction:rtl;
    `;
    catBadge.setAttribute('dir', 'rtl');
    catBadge.textContent = product.category;
    imgBox.appendChild(catBadge);
  }
  card.appendChild(imgBox);

  // ── 3. Parse description ───────────────────────────────────────────────
  const hasArabic = (str: string) => /[\u0600-\u06FF]/.test(str);

  let scientificName = '';   // Latin only — shown LTR italic
  let heightInfo    = '';   // Arabic height text
  let arabicDesc    = '';   // fallback: any Arabic description shown RTL

  if (product.description) {
    const cleaned = product.description.replace(/^\(|\)$/g, '').trim();
    const dashIdx = cleaned.search(/\s[–—-]\s/);
    if (dashIdx > 0) {
      const leftPart = cleaned.slice(0, dashIdx).trim();
      const rest     = cleaned.slice(dashIdx).replace(/^[\s–—-]+/, '').trim();
      const hMatch   = rest.match(/ارتفاع[\s\d.,\-–—]+(?:سم|م)/);
      heightInfo     = hMatch ? hMatch[0] : '';
      if (!hasArabic(leftPart)) {
        scientificName = leftPart;
      } else {
        arabicDesc = leftPart;
      }
    } else {
      const hMatch = cleaned.match(/ارتفاع[\s\d.,\-–—]+(?:سم|م)/);
      heightInfo   = hMatch ? hMatch[0] : '';
      if (!heightInfo) {
        if (hasArabic(cleaned)) {
          arabicDesc = cleaned.slice(0, 50);
        } else {
          scientificName = cleaned.slice(0, 35);
        }
      }
    }
  }

  // ── 4. Text area (name + desc + height) ───────────────────────────────
  const PRICE_BAR_H = 42;
  const TEXT_AREA_H = CARD_INFO_H - PRICE_BAR_H;

  const textArea = document.createElement('div');
  textArea.style.cssText = `
    width:${C_COL}px;
    height:${TEXT_AREA_H}px;
    box-sizing:border-box;
    padding:9px 12px 6px 12px;
    background:#ffffff;
    direction:rtl;
    text-align:right;
    display:block;
    overflow:hidden;
  `;
  textArea.setAttribute('dir', 'rtl');

  // Product name
  const nameEl = document.createElement('div');
  nameEl.style.cssText = `
    font-size:14px;
    font-weight:900;
    color:#0d1f0a;
    line-height:1.25;
    text-align:right;
    direction:rtl;
    display:block;
  `;
  nameEl.setAttribute('dir', 'rtl');
  nameEl.textContent = product.name;
  textArea.appendChild(nameEl);

  // Scientific name (Latin only → LTR italic)
  if (scientificName) {
    const sciEl = document.createElement('div');
    sciEl.style.cssText = `
      font-size:8px;
      color:#8fa68a;
      font-style:italic;
      font-weight:500;
      margin-top:3px;
      direction:ltr;
      text-align:left;
      display:block;
    `;
    sciEl.textContent = scientificName;
    textArea.appendChild(sciEl);
  }

  // Arabic description (fallback when no Latin sci name)
  if (arabicDesc) {
    const descEl = document.createElement('div');
    descEl.style.cssText = `
      font-size:9px;
      color:#64748b;
      font-weight:500;
      margin-top:3px;
      direction:rtl;
      text-align:right;
      display:block;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    `;
    descEl.setAttribute('dir', 'rtl');
    setRtlHtml(descEl, arabicDesc);
    textArea.appendChild(descEl);
  }

  // Height info (Arabic)
  if (heightInfo) {
    const htEl = document.createElement('div');
    htEl.style.cssText = `
      font-size:9px;
      color:#4a7c59;
      font-weight:700;
      margin-top:3px;
      direction:rtl;
      text-align:right;
      display:block;
    `;
    htEl.setAttribute('dir', 'rtl');
    setRtlHtml(htEl, heightInfo);
    textArea.appendChild(htEl);
  }

  card.appendChild(textArea);

  // ── 5. Price bar — solid block at bottom ──────────────────────────────
  const priceBar = document.createElement('div');
  priceBar.style.cssText = `
    width:${C_COL}px;
    height:${PRICE_BAR_H}px;
    box-sizing:border-box;
    background:${s.header};
    display:block;
    padding:0 12px;
    line-height:${PRICE_BAR_H}px;
    direction:rtl;
  `;

  // Use a table to put price on right and unit on left (RTL: price=right)
  const tbl = document.createElement('table');
  tbl.style.cssText = 'width:100%;border-collapse:collapse;direction:rtl;';
  const tr = document.createElement('tr');

  // Price cell (right side in RTL)
  const tdPrice = document.createElement('td');
  tdPrice.style.cssText = 'text-align:right;vertical-align:middle;line-height:1;padding:0;';
  const priceNum = document.createElement('span');
  priceNum.style.cssText = 'font-size:20px;font-weight:900;color:#ffffff;vertical-align:baseline;';
  priceNum.textContent = Number(product.price).toLocaleString('ar-JO');
  const priceCur = document.createElement('span');
  priceCur.style.cssText = `font-size:10px;font-weight:700;color:${s.text};vertical-align:baseline;margin-right:3px;`;
  priceCur.textContent = 'د.أ';
  tdPrice.appendChild(priceNum);
  tdPrice.appendChild(priceCur);

  // Unit cell (left side in RTL)
  const tdUnit = document.createElement('td');
  tdUnit.style.cssText = 'text-align:left;vertical-align:middle;padding:0;';
  const unitPill = document.createElement('span');
  unitPill.style.cssText = `
    display:inline-block;
    background:rgba(255,255,255,0.2);
    color:#ffffff;
    font-size:9.5px;
    font-weight:800;
    padding:3px 10px;
    border-radius:20px;
    border:1px solid rgba(255,255,255,0.4);
    line-height:1.4;
  `;
  unitPill.textContent = product.unit || 'وحدة';
  tdUnit.appendChild(unitPill);

  tr.appendChild(tdPrice);
  tr.appendChild(tdUnit);
  tbl.appendChild(tr);
  priceBar.appendChild(tbl);
  card.appendChild(priceBar);

  return card;
}

// ── Build one row (3 cards) ───────────────────────────────────────────────
async function buildRow(cards: Product[]): Promise<HTMLElement> {
  const row = mkEl('div', `display:flex;gap:${C_GAP}px;height:${CARD_H}px;align-items:stretch;`);
  for (const p of cards) row.appendChild(await buildCard(p));
  // fill remaining slots with invisible placeholders
  for (let i = cards.length; i < COLS; i++) {
    row.appendChild(mkEl('div', `width:${C_COL}px;flex-shrink:0;`));
  }
  return row;
}

// ── Build category header bar ─────────────────────────────────────────────
function buildCatHeader(label: string, count: number): HTMLElement {
  const s = CATEGORY_STYLES[label] || CATEGORY_STYLES['متنوعة'];

  const wrap = mkEl('div', `
    height:${CAT_H}px;
    background:linear-gradient(135deg,${s.header} 0%,${s.bar.split(',')[0]} 100%);
    border-radius:14px;
    overflow:hidden;
    display:flex;
    align-items:stretch;
    flex-shrink:0;
    box-shadow:0 3px 10px rgba(0,0,0,0.18);
  `);
  wrap.setAttribute('dir', 'rtl');

  // Thick accent stripe
  wrap.appendChild(mkEl('div', `width:10px;background:linear-gradient(180deg,${s.badge},${s.bar.split(',')[1] || s.badge});flex-shrink:0;`));

  // Inner content
  const inner = mkEl('div', `
    flex:1;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 20px 0 14px;
    direction:rtl;
  `);
  inner.setAttribute('dir', 'rtl');

  // Right side: icon + label (in RTL, first child is on the right)
  const labelSide = mkEl('div', 'display:flex;align-items:center;gap:10px;direction:rtl;');
  labelSide.setAttribute('dir', 'rtl');

  const labelEl = mkEl('div', `
    font-size:21px;
    font-weight:900;
    color:#ffffff;
    font-family:'Cairo',Arial,sans-serif;
    text-shadow:0 1px 4px rgba(0,0,0,0.35);
    direction:rtl;
  `);
  labelEl.setAttribute('dir', 'rtl');
  labelEl.textContent = label;

  labelSide.appendChild(mkEl('span', 'font-size:20px;line-height:1;', '🌱'));
  labelSide.appendChild(labelEl);
  inner.appendChild(labelSide);

  // Left side: count badge
  const countBadge = mkEl('div', `
    background:rgba(255,255,255,0.22);
    color:#ffffff;
    font-size:11.5px;
    font-weight:800;
    padding:5px 16px;
    border-radius:20px;
    border:1.5px solid rgba(255,255,255,0.45);
    white-space:nowrap;
    direction:rtl;
  `);
  countBadge.setAttribute('dir', 'rtl');
  countBadge.textContent = `${count} صنف`;
  inner.appendChild(countBadge);

  wrap.appendChild(inner);
  return wrap;
}

// ── Build main page header (page 1 only) ──────────────────────────────────
async function buildMainHeader(totalCount: number, logoSrc: string): Promise<HTMLElement> {
  const wrap = mkEl('div', 'margin-bottom:0;');

  const hdr = mkEl('div', `
    background:linear-gradient(135deg,#0d2b1e 0%,#1a4a2e 50%,#22603a 100%);
    padding:20px ${C_PAD + 8}px 16px;
    display:flex;align-items:center;gap:18px;
    border-bottom:4px solid #52b788;
  `);
  const logoData = logoSrc ? await loadImageAsDataUrl(logoSrc) : '';
  if (logoData) {
    const lw = mkEl('div', 'width:92px;height:92px;background:#fff;border-radius:14px;display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:4px;box-shadow:0 4px 14px rgba(0,0,0,0.3);');
    const li = document.createElement('img') as HTMLImageElement;
    li.src = logoData;
    li.style.cssText = 'width:84px;height:84px;object-fit:contain;';
    lw.appendChild(li);
    hdr.appendChild(lw);
  }
  const ht = mkEl('div', 'flex:1;direction:rtl;');
  ht.setAttribute('dir', 'rtl');
  const companyNameEl = mkEl('div', 'font-size:27px;font-weight:900;color:#ffffff;line-height:1.1;direction:rtl;');
  companyNameEl.setAttribute('dir', 'rtl');
  companyNameEl.textContent = 'مؤسسة ومشاتل القادري الزراعية';
  ht.appendChild(companyNameEl);
  ht.appendChild(mkEl('div', 'font-size:11.5px;color:#86efac;direction:ltr;text-align:left;margin-top:5px;font-weight:600;letter-spacing:0.6px;', 'Al-Qadri Agricultural Nursery & Establishment'));
  ht.appendChild(mkEl('div', 'height:1px;background:rgba(255,255,255,0.18);margin:10px 0;'));
  const priceListEl = mkEl('div', 'font-size:13.5px;color:#d1fae5;font-weight:700;direction:rtl;');
  priceListEl.setAttribute('dir', 'rtl');
  priceListEl.textContent = 'قائمة الأسعار';
  ht.appendChild(priceListEl);
  hdr.appendChild(ht);
  wrap.appendChild(hdr);

  const info = mkEl('div', `background:#ffffff;padding:8px ${C_PAD + 8}px;border-bottom:1px solid #d1fae5;display:flex;justify-content:space-between;align-items:center;direction:rtl;`);
  info.setAttribute('dir', 'rtl');
  const ph = mkEl('div', 'display:flex;align-items:center;gap:6px;direction:rtl;');
  ph.setAttribute('dir', 'rtl');
  ph.appendChild(mkEl('span', 'font-size:12.5px;color:#166534;font-weight:700;direction:ltr;unicode-bidi:embed;', COMPANY_PHONE));
  const hatelEl = mkEl('span', 'font-size:12.5px;color:#166534;direction:rtl;');
  hatelEl.setAttribute('dir', 'rtl');
  hatelEl.textContent = 'هاتف:';
  ph.appendChild(hatelEl);
  info.appendChild(ph);
  const dateEl = mkEl('span', 'font-size:10.5px;color:#64748b;font-weight:600;direction:rtl;');
  dateEl.setAttribute('dir', 'rtl');
  dateEl.textContent = `تاريخ الإصدار: ${new Date().toLocaleDateString('ar-JO', { year: 'numeric', month: 'long', day: 'numeric' })}`;
  info.appendChild(dateEl);
  const totalEl = mkEl('span', 'font-size:10.5px;color:#64748b;font-weight:600;direction:rtl;');
  totalEl.setAttribute('dir', 'rtl');
  totalEl.textContent = `إجمالي الأصناف: ${totalCount}`;
  info.appendChild(totalEl);
  wrap.appendChild(info);
  return wrap;
}

// ── Build page footer ─────────────────────────────────────────────────────
function buildFooter(pageNum: number, totalPages: number): HTMLElement {
  const f = mkEl('div', `
    height:${FOOTER_H}px;
    background:linear-gradient(135deg,#0d2b1e,#22603a);
    display:flex;justify-content:space-between;align-items:center;
    padding:0 ${C_PAD + 8}px;
    border-top:3px solid #52b788;
    flex-shrink:0;
  `);
  const footerNameEl = mkEl('div', 'color:#d1fae5;font-size:10.5px;font-weight:700;direction:rtl;');
  footerNameEl.setAttribute('dir', 'rtl');
  footerNameEl.textContent = 'مؤسسة ومشاتل القادري الزراعية';
  f.appendChild(footerNameEl);
  f.appendChild(mkEl('div', 'color:#86efac;font-size:10.5px;font-weight:600;', `${pageNum} / ${totalPages}`));
  f.appendChild(mkEl('div', 'color:#86efac;font-size:10.5px;font-weight:700;direction:ltr;', `${COMPANY_PHONE} :☎`));
  return f;
}

// ── Render one A4 page ────────────────────────────────────────────────────
async function renderPage(
  pageItems: PageItem[],
  isFirst: boolean,
  logoSrc: string,
  totalCount: number,
  pageNum: number,
  totalPages: number
): Promise<HTMLCanvasElement> {
  const styleEl = document.createElement('style');
  styleEl.textContent = `@import url('${FONT_URL}'); * { font-family: 'Cairo', Arial, sans-serif !important; box-sizing: border-box; }`;

  const page = mkEl('div', `
    width:${A4_W}px;
    height:${A4_H}px;
    background:#f0f4f0;
    font-family:'Cairo',Arial,sans-serif;
    direction:rtl;
    text-align:right;
    overflow:hidden;
    display:flex;
    flex-direction:column;
    position:relative;
  `);
  page.setAttribute('dir', 'rtl');
  page.appendChild(styleEl);

  // ── main header (page 1 only) ──
  if (isFirst) {
    page.appendChild(await buildMainHeader(totalCount, logoSrc));
  }

  // ── content area ──
  const content = mkEl('div', `
    flex:1;
    padding:${C_PAD}px;
    display:flex;
    flex-direction:column;
    gap:${C_GAP}px;
    overflow:hidden;
  `);

  for (const item of pageItems) {
    if (item.type === 'cat') {
      content.appendChild(buildCatHeader(item.label, item.count));
    } else {
      const rowEl = await buildRow(item.cards);
      content.appendChild(rowEl);
    }
  }
  page.appendChild(content);

  // ── footer ──
  page.appendChild(buildFooter(pageNum, totalPages));

  // ── render to canvas ──
  page.style.position = 'fixed';
  page.style.top = '-99999px';
  page.style.left = '-99999px';
  page.style.zIndex = '-1';
  document.body.appendChild(page);
  await new Promise(r => setTimeout(r, 300));

  const fontCss = await getCairoFontCSS();
  const canvas = await html2canvas(page, {
    scale: 3,
    useCORS: true,
    logging: false,
    backgroundColor: '#f0f4f0',
    allowTaint: true,
    imageTimeout: 20000,
    windowWidth: A4_W,
    width: A4_W,
    height: A4_H,
    onclone: async (doc: Document) => {
      doc.documentElement.setAttribute('dir', 'rtl');
      doc.documentElement.style.direction = 'rtl';
      const style = doc.createElement('style');
      style.textContent = fontCss + '\n* { font-family: "Cairo", Arial, sans-serif !important; }';
      doc.head.appendChild(style);
      try { await doc.fonts.ready; } catch {}
    },
  });

  document.body.removeChild(page);
  return canvas;
}

// ── Main export function ──────────────────────────────────────────────────
export const exportCatalogToPDF = async (products: Product[]) => {
  try {
    await ensureCairoFont();

    const items   = buildItemList(products);
    const pages   = assignToPages(items);
    const total   = pages.length;
    const logoSrc = '/logo.png';

    const pdf    = new SimplePDF();
    const pdfW   = pdf.getPageWidth();
    const pdfH   = pdf.getPageHeight();

    for (let i = 0; i < pages.length; i++) {
      if (i > 0) pdf.addPage('a4');

      const canvas = await renderPage(pages[i], i === 0, logoSrc, products.length, i + 1, total);

      const imgData = canvas.toDataURL('image/jpeg', 0.97);
      const ratio   = canvas.height / canvas.width;
      pdf.addImage(imgData, 'JPEG', 0, 0, pdfW, pdfW * ratio);

      // If the rendered height exceeds one PDF page height, warn (shouldn't happen now)
      if (pdfW * ratio > pdfH) {
        console.warn(`Page ${i + 1} exceeds A4 height — layout may need adjustment`);
      }
    }

    const dateStr = new Date().toLocaleDateString('ar-JO').replace(/\//g, '-');
    pdf.save(`كتالوج-مشاتل-القادري-${dateStr}.pdf`);
  } catch (err) {
    console.error('Catalog PDF error:', err);
    throw err;
  }
};
